#include<stdio.h>
#include<string.h>
#include<stdlib.h>
void main()
{
char a[10],label[10],opcode[10],operand[10],symbol[10],ch;
int c=0;
int sa,st,diff,diff1=0,i,address,add,len,actual_len,finaddr,prevaddr,j=0;
char mnemonic[15][15]={"LDA","STA","LDCH","STCH"};
char code[15][15]={"33","44","53","57"};
FILE *fp1,*fp2,*fp3,*fp4;
clrscr();
fp1=fopen("c:\\turboc3\\bin\\project\\ASSMLIST.DAT","w");
fp2=fopen("c:\\turboc3\\bin\\SYMTAB.DAT","r");
fp3=fopen("c:\\turboc3\\bin\\INTER.DAT","r");
fp4=fopen("c:\\turboc3\\bin\\project\\OBJECT.DAT","w"); 
fscanf(fp3,"%s%s%s",label,opcode,operand);
while(strcmp(opcode,"END")!=0)
{
if(strcmp(opcode,"START")==0)
sa=atoi(operand);
if(strcmp(opcode,"RESW")==0)
{
c=3*atoi(operand);
diff1+=c;
}
if(strcmp(opcode,"RESB")==0)
{
c=atoi(operand);
diff1+=c;
}
prevaddr=address;
fscanf(fp3,"%d%s%s%s%s",&address,label,opcode,operand);
}
finaddr=address-sa;
diff=finaddr-diff1;
fclose(fp3);
fp3=fopen("c:\\turboc3\\bin\\project\\INTERMED.DAT","r");
fscanf(fp3,"%s%s%s",label,opcode,operand);
if(strcmp(opcode,"START")==0)
{
fprintf(fp1,"\t%s\t%s\t%s\n",label,opcode,operand);
fprintf(fp4,"H^%s^%s^0000%d\n",label,operand,finaddr);
fscanf(fp3,%d%s%s%s",&address,label,opcode,operand);
st=address;
fprintf(fp4,"T^00%d^%d",address,diff);
}
while(strcmp(opcode,"END")!=0)
{
if(strcmp(opcode,"BYTE")==0)
{
fprintf(fp1,"%d\t%s\t%s\t%s\t",address,label,opcode,operand);
len=strlen(operand);
actual_len=len-3;
fprintf(fp4,"^");
for(i=2;i<(actual_len+2);i++)
{
fprintf(fp1,"%x",operand[i]);
fprintf(fp4,"%x",operand[i]);
}
fprintf(fp1,"\n");
}
else if(strcmp(opcode,'WORD")==0)
{
len=strlen(operand);
fprintf(fp1,"%d\t%s\t%s\t%s\t00000%s\n",address,label,opcode,operan
d,operand);
fpintf(fp4,"^00000%s:,operand);
}
else if((strcmp(opcode,"RESB")==0) || 
(strcmp(opcode,"RESW")==0))
fprintf(fp1,"%d\t%s\t%s\t%s\n",address,label,opcode.operand);
else
{
while(strcmp(opcode,mnemonic[j]!=0)
{
j++;
getch();
}
if(strcmp(opcode,"COPY")==0)
fprintf(fp1,"%d\t%s\t%s\t%s\t%s0000\n",address,label,opcode,operand,
code[j]);
else
{
rewind(fp2);
fscanf(fp2,"%s%d",symbol,&add);
while(strcmp(operand,symbol)!=0)
fscanf(fp2,"%s%d",symbol,&add);
printf("\n j=%d",j);
getch();
fprintf(fp1,"%d\t%s\t%s\t%s\t%s%d\n",address,label,opcode,operand,c
ode[j],add);
fprintf(fp4,"^%s%d",code[j],add);
}
}
fscanf(fp3,"%d%s%s%s",&address,label,opcode,operand);
}
fprintf(fp1,"%d\t%s\t%s\t%s\n",address,label,opcode,operand);
fprintf(fp4,"\nE^00%d",st);
printf("\nIntermediate file is converted into object code:);
fcloseall();
printf("\n\nThe contents of the Intermediate file :\n\n\t");
fp3=fopen("c:\\turboc3\\bin\\project\\INTER.DAT","r");
ch=fgetc(fp3);
while(ch!=EOF)
{
printf("%c",ch);
ch=fgetc(fp3);
}
printf("\n\nThe contents of the Symbol Table :\n\n");
fp2=fopen("c:\\turboc3\\bin\\SYMTAB.DAT","r");
ch=fgetc(fp2);
while(ch!=EOF)
{
printf("%c",ch);
ch=fgetc(fp2);
}
printf("\n\nThe contents of the Output file :\n\n");
fp1=fopen("c:\\turboc3\\bin\\project\\ASSMLIST.DAT","r");
ch=fgetc(fp1);
while(ch!=EOF)
{

printf("%c",ch);
ch=fgetc(fp1);
}
printf("\n\nThe contents of the Object code file :\n\n");
fp4=fopen("c:\\turboc3\\bin\\project\\OBJCODE.DAT","r");
ch=fgetc(fp4);
while(ch!=EOF)
{
printf("%c",ch);
ch=fgetc(fp4);
}
fcloseall();
}

############################################
############################################
SAMPLE INPUT AND OUTPUT
ALPHA 200C
FIVE 200F
CHARZ 2012
C1 2015
The contents of the Output file : 
 COPY START 2000
2000 ** LDA FIVE 33200F
2003 ** STA ALPHA 44200C
2006 ** LDCH CHARZ 532012
2009 ** STCH C1 572015
200C ALPHA RESW 1 
200F FIVE WORD 5 000005
2012 CHARZ BYTE C’EOF’ 454F46
2015 C1 RESB 1
2018 ** END ** 
The contents of the Object code file :
H^COPY^002000^000022
T^002000^18^332015^442012^532018^572021^000005^454F46
E^002000
###############################################
###############################################