#include<stdio.h> 
#include<stdbool.h> 
void readSystem(int m,int available[]) 
{ 
 for(int i=0;i<m;i++) 
 { 
 printf("Enter number of instances of resource %d\n",i+1); 
 scanf("%d",&available[i]); 
 } 
} 
//function to read allocatuion and max need of resources for processes 
void readProcess(int n,int m,int allocation[][50],int max[][50]) 
{ 
 for(int i=0;i<n;i++) 
 { 
 for(int j=0;j<m;j++) 
 { 
 printf("Enter Allocation of resource %d of process %d\n",(j+1),(i+1)); 
 scanf("%d",&allocation[i][j]); 
 printf("Enter maximum need of resource %d of process %d\n",(j+1),(i+1)); 
 scanf("%d",&max[i][j]); 
 } 
 } 
} 
//function to calculate available and need of each process 
void calculateAvailableAndNeed(int n,int m,int available[],int allocation[][50],int max[][50],int 
need[][50]) 
{ 
 int i,j; 
 for(i=0;i<m;i++) 
 { 
 for(j=0;j<n;j++) 
 { 
 available[i]=available[i]-allocation[j][i]; 
 } 
 } 
 for(i=0;i<n;i++) 
 { 
 for(j=0;j<m;j++) 
 { 
 need[i][j]=max[i][j]-allocation[i][j]; 
 } 
 } 
} 
//function to simulate allocation and check safety and to print the outout 
void safetyAlgorithm(int n,int m,int available[],int need[][50],int allocation[][50]) 
{ 
 bool flag=false,flag1=true; 
 int work[m],i,j,k,safeSequence[n],count=0; 
 bool finish[n]; 
 for(i=0;i<m;i++) 
 { 
 work[i] = available[i]; 
 } 
 for(i=0;i<n;i++) 
 { 
 finish[i]=false; 
 } 
 for(i=0;i<n;i++) 
 { 
 for(j=0;j<n;j++) 
 { 
 if(finish[j]==false) 
 { 
 for(k=0;k<m;k++) 
 { 
 if(need[j][k]>work[k]) 
 { 
 flag1=false; 
 break; 
 } 
 else 
 flag1=true; 
 } 
 if(flag1==true) 
 { 
 for(k=0;k<m;k++) 
 { 
 work[k]=work[k]+allocation[j][k]; 
 } 
 finish[j]=true; 
 safeSequence[count]=j; 
 count++; 
 } 
 } 
 } 
 } 
 for(i=0;i<n;i++) 
 { 
 if(finish[i]==true) 
 flag=true; 
 else 
 { 
 flag=false; 
 break; 
 } 
 } 
 if(flag==true) 
 { 
 printf("System is in safe state\n"); 
 printf("Safe Sequence is \n"); 
 for(i=0;i<n;i++) 
 printf("P%d -> ",safeSequence[i]+1); 
 printf("\n"); 
 } 
 else 
 printf("System is not in safe state\n"); 
} 
void main() 
{ 
 int n,m; 
 printf("enter number of resources\n"); 
 scanf("%d",&m); 
 int available[m]; 
 readSystem(m,available); 
 printf("enter number of processes\n"); 
 scanf("%d",&n); 
 int allocation[n][m]; 
 int max[n][m]; 
 int need[n][m]; 
 readProcess(n,m,allocation,max); 
 calculateAvailableAndNeed(n,m,available,allocation,max,need); 
 safetyAlgorithm(n,m,available,need,allocation); 
} 

#####################################
#####################################
SAMPLE INPUT AND OUTPUT
INPUT :
Enter number of resources : 3
Enter number of instances of resource 1 : 10
Enter number of instances of resource 2 : 5
Enter number of instances of resource 3 : 7
enter number of processes : 5
Enter Allocation of resource 1 of process 1 : 0
Enter maximum need of resource 1 of process 1 : 7
Enter Allocation of resource 2 of process 1 : 1
Enter maximum need of resource 2 of process 1 : 5
Enter Allocation of resource 3 of process 1 : 0
Enter maximum need of resource 3 of process 1 : 3
Enter Allocation of resource 1 of process 2 : 2
Enter maximum need of resource 1 of process 2 : 3
Enter Allocation of resource 2 of process 2 : 0
Enter maximum need of resource 2 of process 2 : 2
Enter Allocation of resource 3 of process 2 : 0
Enter maximum need of resource 3 of process 2 : 2
Enter Allocation of resource 1 of process 3 : 3
Enter maximum need of resource 1 of process 3 : 9
Enter Allocation of resource 2 of process 3 : 0
Enter maximum need of resource 2 of process 3 : 0
Enter Allocation of resource 3 of process 3 : 2
Enter maximum need of resource 3 of process 3 : 2
Enter Allocation of resource 1 of process 4 : 2
Enter maximum need of resource 1 of process 4 : 2
Enter Allocation of resource 2 of process 4 : 1
Enter maximum need of resource 2 of process 4 : 2
Enter Allocation of resource 3 of process 4 : 1
Enter maximum need of resource 3 of process 4 : 2
Enter Allocation of resource 1 of process 5 : 0
Enter maximum need of resource 1 of process 5 : 4
Enter Allocation of resource 2 of process 5 : 0
Enter maximum need of resource 2 of process 5 : 3
Enter Allocation of resource 3 of process 5 : 2
Enter maximum need of resource 3 of process 5 : 3


OUTPUT :
System is in safe state
Safe Sequence is 
P2 -> P4 -> P5 -> P1 -> P3

###########################################
###########################################